class BookShelf {
  constructor() {
    this.bookOnShelf = [];
  }
  //   this is my add a books to the bookshelf method
  addBook(aBook) {
    this.bookOnShelf.push(aBook);
  }
  //   this is the render method to populate the DOM wth the list of books on the container
  render() {
    let board = document.querySelector("#container");
    let booksOnShelf = document.createElement("ul");
    // I need to loop through the array of books and call it this.booksOnShelf since it is an empty array and then have books pushed into the empty array
    for (const bookItems of this.bookOnShelf) {
      booksOnShelf.append(bookItems.render());
    }
    board.append(booksOnShelf);
  }
  //   this is looping through the array of books in the bookdata.js
  arrBook(arrOfBook) {
    for (const book of arrOfBook) {
      let bookInstance = new Book(
        book.author,
        book.language,
        book.subject,
        book.title
      );
      //   this adding the books to tbe bookshelf
      bookShelf.addBook(bookInstance);
    }
  }
}
// testing the books and bookshelf classes to make sure everything is running correctly
let book1 = new Book("author1", "english", "biology", "birds and the bees");
let bookShelf = new BookShelf();
// calling instance of the book array to take place in the bookData and calling the render instance
bookShelf.arrBook(bookData);
bookShelf.render();
// let book1 = new Book("author1", "english", "biology", "birds and the bees");
