// Variables
const titleInput = document.querySelector("#title");
const authorInput = document.querySelector("#author");
const subjectInput = document.querySelector("#subject");
const languageInput = document.querySelector("#language");
const button = document.querySelector(".btn");
const bookShelf = document.querySelector("#book-shelf");

button.addEventListener("click", function () {
  if (
    titleInput.value == "" &&
    authorInput.value == "" &&
    subjectInput.value == "" &&
    languageInput.value == ""
  ) {
    alert("Enter value");
  } else {
    const bookShelfRow = document.createElement("tr");

    const newTitle = document.createElement("th");
    newTitle.innerHTML = titleInput.value;
    bookShelfRow.appendChild(newTitle);

    const newAuthor = document.createElement("th");
    newAuthor.innerHTML = authorInput.value;
    bookShelfRow.appendChild(newAuthor);

    const newSubject = document.createElement("th");
    newSubject.innerHTML = subjectInput.value;
    bookShelfRow.appendChild(newSubject);

    const newLanguage = document.createElement("th");
    newLanguage.innerHTML = languageInput.value;
    bookShelfRow.appendChild(newLanguage);

    bookShelf.appendChild(bookShelfRow);
  }
});
