// here I am creating the book class for all of the attributes that are in the book such as author, language, subject and title

class Book {
  constructor(author, language, subject, title) {
    this.author = author;
    this.language = language;
    this.subject = subject;
    this.title = title;
  }
//   while rendering the books since there was a lot of information I wanted to have just the author and title be present on the page
  render() {
    let library = document.createElement("section");
    library.classList.add('library');
    let libraryWrapper = document.createElement('li')
    libraryWrapper.classList.add('libraryWrapper');
    
    let libraryBooks = document.createElement("h2");
    libraryBooks.textContent = `${this.title}`;
// I wanted to have the title of the books be the first thing you see since that's how books are labeled in a library
    let libraryAuthor = document.createElement("ol");
    for (const book of this.author) {
        // this is the list of author section since the authors were in a array in the data I had to loop through each book to get the authors name to generate
      let bookAuthor = document.createElement("li");
      
      bookAuthor.textContent = `By: ${this.author}`;
    //   I am appending the ol of the authors to the li on the to the ol 
      libraryAuthor.append(bookAuthor);
    }
    // I am appending both the book titles and the book authors to the page
    library.append(libraryBooks, libraryAuthor);

    return library;
  }
}
// creating the class for the bookshelf and to have it return as an empty array so that I can populate it with books from the data.
